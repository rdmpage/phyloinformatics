/* This software is distributed under the GNU Lesser General Public License */
//==========================================================================
//
//   version.h.in - GTL version
//
//==========================================================================
// $Id: version.h.in,v 1.1 1999/02/18 18:46:59 forster Exp $

#ifndef GTL_VERSION_H
#define GTL_VERSION_H

#define GTL_MAJOR_VERSION "@MAJOR_VERSION@"
#define GTL_MINOR_VERSION "@MINOR_VERSION@"
#define GTL_MINI_VERSION "@MINI_VERSION@"

#endif // GT_VERSION_H

//--------------------------------------------------------------------------
//   end of file
//--------------------------------------------------------------------------
